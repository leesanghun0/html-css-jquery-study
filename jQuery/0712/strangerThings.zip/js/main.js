$(".logo").fadeIn(2000); 
